﻿using MazeTest.Model;
using System.Data;

namespace MazeTest.ViewModel
{
    public interface IMazeViewModel
    {
        void DrawMaze();

        string _maze { get; set; }

        MazePointValue GetStartorFinish(string value);

        DataTable MazeTable
        {
            get;
            set;
        }

        string GetValue(int rowIndex, int columnIndex);
    }
}
