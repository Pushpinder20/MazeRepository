﻿using System;
using System.Data;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Media;
using System.Globalization;

namespace MazeTest.Converter
{
    public class ValueToBrushConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            string input;
            try
            {
                DataGridCell cell = (DataGridCell)value;
                DataRowView rowView = (DataRowView)cell.DataContext;
                input = rowView.Row.ItemArray[cell.Column.DisplayIndex].ToString();

            }
            catch (InvalidCastException e)
            {
                return DependencyProperty.UnsetValue;
            }
            switch (input)
            {
                case "F":
                case "S":
                    return Brushes.Red;
                case " ": return Brushes.White;
                case "X": return Brushes.Gray;
                case ".": return Brushes.LightGreen;
                case "*": return Brushes.Green;
                default: return DependencyProperty.UnsetValue;
            }
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotSupportedException();
        }

    }
}
