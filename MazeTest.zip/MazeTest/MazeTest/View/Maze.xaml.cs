﻿using MazeTest.ViewModel;
using System.Windows;

namespace MazeTest.View
{
    public partial class Maze : Window
    {
        private MazeViewModel mazeViewModel = null;
        public Maze()
        {
            InitializeComponent();
            mazeViewModel = new MazeViewModel();
            DataContext = mazeViewModel;
        }
    }
}
