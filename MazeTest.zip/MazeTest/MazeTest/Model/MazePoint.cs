﻿namespace MazeTest.Model
{
    public class MazePoint
    {
        public MazePoint()
        {
        }

        public MazePoint(int rowValue, int columnValue)
        {
            row = rowValue;
            column = columnValue;
        }

        public int row { get; set; }

        public int column { get; set; }
    }
}
